window.onload = function () {
    alert('Hello')
}